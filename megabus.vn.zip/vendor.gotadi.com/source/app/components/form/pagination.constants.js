(function() {
    'use strict';

    angular
        .module('B2B2CGatewayApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();